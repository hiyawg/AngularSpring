import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
success : string;
error: string;
  constructor(private http:HttpClient,private router: Router) { }

  ngOnInit() {
  }

  public regesterEmployee(form: any) {
    this.http.post('/employees', form)
    .subscribe(
      data => {
        console.log('Patient Regestration is successful ', data);
        this.success = 'You have successfully regestered ' + form.empfirstname + ' ' + form.emplastname;
    },
    error => {
        console.log('Error', error);
        this.error = error;
    }
    );
  }

  public destroy() {
    this.error = null;
    this.success = null;
  }

}
