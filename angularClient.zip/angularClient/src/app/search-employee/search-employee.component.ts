import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {
  patientSearchResult : any;
  constructor(private http:HttpClient,private router:Router) { }

  ngOnInit() {
  }
  public searchPatient (search: any) {
    this.http.post('/employees/search', search)
        .subscribe(
            data => {
                console.log('POST Request is successful ', data);
                this.patientSearchResult = data;
            },
            error => {
                console.log('Error', error);
            }
        );
  }

}
