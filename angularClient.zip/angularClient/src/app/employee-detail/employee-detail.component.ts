import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {Observable} from 'rxjs';
@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css']
})
export class EmployeeDetailComponent implements OnInit {
  employee: any;
  address: any;
  employeeid : any;
  constructor(private http:HttpClient,private route: ActivatedRoute) { 
    this.employee = null;
  }

  ngOnInit() {
    this.employeeid = this.route.snapshot.paramMap.get('id');
    console.log('patient id: ', this.employeeid);
    this.getPatientById(this.employeeid);
  }

  

  public getPatientById(id: string) {
    // patient
    this.http.get('/employees/' + id)
    .subscribe(
      data => {
        this.employee = data;
      },
      error => {
        console.log('error: getPatientById', error);
      }
    );

    // address
    this.http.get('/employees/address/' + id)
    .subscribe(
      data => {
        this.address = data;
      },
      error => {
        console.log('error: getPatientById', error);
      }
    );

    

  }

}
